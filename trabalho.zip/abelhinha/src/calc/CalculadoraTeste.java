package calc;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class CalculadoraTeste {

	@Test
	void testSomar() {
		Calculadora cal = new Calculadora();
		double a = 4;
		double b = 2;
		
		assertEquals(cal.somar(a, b), 6);
	}
	
	@Test
	void testMultiplicar() {
		Calculadora cal = new Calculadora();
		double a = 4;
		double b = 2;
		
		assertEquals(cal.multiplicar(a, b), 8);
	}

	@Test
	void testDividir() {
		Calculadora cal = new Calculadora();
		double a = 4;
		double b = 0;
		
		if(b!=0)
			assertEquals(cal.dividir(a, b), 2);
		else
			System.out.println("N�o pode dividir por 0");
	}

	@Test
	void testSubtrair() {
		Calculadora cal = new Calculadora();
		double a = 4;
		double b = 2;
		
		assertEquals(cal.subtrair(a, b), 2);
	}

	@Test
	void testExponenciar() {
		Calculadora cal = new Calculadora();
		double a = 4;
		double b = 2;
		
		assertEquals(cal.exponenciar(a, b), 16);
	}

	@Test
	void testRaiz() {
		Calculadora cal = new Calculadora();
		double a = 4;
		
		assertEquals(cal.raiz(a), 2);
	}

}
