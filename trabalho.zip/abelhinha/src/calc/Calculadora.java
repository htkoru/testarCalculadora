package calc;

//complementar a calculadora com os metodos de multiplicacao, divisao, subtracao, exponenciacao e raiz quadrada.

public class Calculadora {
	
	public double somar(double a, double b) {
		return a+b;
	}
	
	public double multiplicar(double a, double b) {
		return a*b;
	}
	
	public double dividir(double a, double b) {
		return a/b;
	}
	
	public double subtrair(double a, double b) {
		return a-b;
	}
	
	public double exponenciar(double a, double b) {
		return Math.pow(a, b);
	}
	
	public double raiz(double a) {
		return Math.sqrt(a);
	}
	
	public static void main(String[] args) {
		
	}
}
